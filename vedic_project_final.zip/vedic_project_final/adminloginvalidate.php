<?php
session_start();
include_once "dbconfig.php";

$user = $_POST["username"];
$pwd = $_POST["psw"];

$pwd = MD5($pwd);

$sql = "SELECT * FROM adminusers where username = '$user' and password = '$pwd'";
$result = mysqli_query($con,$sql);

if(mysqli_num_rows($result) > 0) {
	$row = mysqli_fetch_assoc($result);
	$_SESSION['username'] = $row["username"];
	$_SESSION['adminid'] = $row["adminid"];
	echo '<script>window.location.href = "Inbox.php";</script>';
	} else {
		echo "<script type='text/javascript'>alert('Invalid Credentials!')</script>";
		echo '<script>window.location.href = "admin/adminlogin.html";</script>';
	}

?>
