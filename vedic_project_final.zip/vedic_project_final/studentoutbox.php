<?php
session_start();
include_once "dbconfig.php";
include_once "pagination.php";
$id = $_SESSION['id'];
$sql = "select * from studentoutbox where id = '$id' order by date desc";
$result = mysqli_query($con,$sql);
?>

<html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<title>Post</title>
<style>

#header {
 background-color:#009900;
 height:5%;
}
body {
    background-image: url("images/img.jpeg");
    background-size: 100%;
    background-repeat: no-repeat;
}

.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: ;
   color: green;
   text-align: center;
}
#body {

 background-color:#ffffff;
 height:80%;
 padding: 10px;
 overflow:auto;

}
#right {
	float: right;
	height: 12%;
	padding: 10px;

}
.topnav {
  overflow: hidden;
  background-color: ;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}

</style>
</head>

<body>

<div class="topnav">

	<img src="logos/Vishnu_Universal_Learning.png"  alt="logo" style="width:70px;height:70px;">
	<div id ="right">
		<a href="studentPost.php">Post</a>
		<a href="studentInbox.php"><center>Inbox</center></a>
		<a href="studentoutbox.php">Outbox</a>
		<a href="studentprofile.php">Profile</a>
		<a href="logout.php">Logout</a>
	</div>
</div>
<div id = "body">
<table class="table">

<?php
$page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
if ($page <= 0) $page = 1;

$per_page = 10; // Set how many records do you want to display per page.

$startpoint = ($page * $per_page) - $per_page;

$statement = "`studentoutbox`"; // Change `records` according to your table name.

$results = mysqli_query($con,"SELECT * FROM {$statement} where id = '$id' LIMIT {$startpoint} , {$per_page}");
if (mysqli_num_rows($results) != 0) {
	$x = 1;
	echo '<thead>
 <tr>
    <th>title</th>
    <th>Date</th>
	<th>Time</th>
  </tr>
  </thead>
  <tbody>';
    while ($row = mysqli_fetch_array($results)) {
			echo '<tr>';
			//echo '<td>'.$x. '</td>';
			echo '<td><a href="completemessage.php?msg='.$row[1].'">'.$row[2].'</a></td>';
			echo '<td>' .$row[4]. '</td>';
			echo '<td>' .$row[5].'</td>';
		echo'</tr>';
		//$x++;
	}
} else {
     echo '<center><h1>No records are found.</h1></center>';
}
echo '</tbody>';
?>
</table>
<center>
<?php echo pagination($statement,$per_page,$page,$url='?'); ?>      </center>
</div>
<div class="footer"><font color="white">
<marquee behavior="scroll" direction="right"><h4>Developed and Maintained by BVRITH Students</h4></marquee>
</div>
</body>
</html>
