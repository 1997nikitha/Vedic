<?php session_start();
include_once "dbconfig.php";
if(isset($_GET['cid'])) {
  $cid = $_GET['cid'];
  $to = "director";
  $status="unseen";
  $stmt = $con->prepare("INSERT INTO admininbox VALUES (?,?,?)");
  $stmt->bind_param("sss", $cid, $to, $status);
  $stmt->execute();
  $stmt->close();
  $con->close();
  echo ("<script LANGUAGE='JavaScript'>
  window.alert('Successfully Forwarded!!');
  window.location.href='Inbox.php';
  </script>");
}
?>
