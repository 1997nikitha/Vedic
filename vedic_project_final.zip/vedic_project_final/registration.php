<?php
include_once "dbconfig.php";
$valid = 1;
$username = $_POST["username"];
$crse = $_POST["course"];
$college = $_POST["college"];
$department = $_POST["department"];
$email = $_POST["email"];
$password = $_POST["psw"];
$confirm_password = $_POST["psw-repeat"];
$pwd = MD5($password);

if ($confirm_password != $password) {
    $status = "Passwords do not match!";
    $valid = 0;
}
if ($crse == "bvritce_pg" || $crse == "bvritn_pg" || $crse == "svcp_pg" || $crse == "svecw_pg" || $crse == "vdc_pg" ||$crse == "viper_pg" || $crse == "vip_pg") {
    $course = "PG";
} else {
    $course = "UG";
}
//echo $username. $crse . $college . $department . $email . $password;
$sql = "select * from users where username = '$username'";
$result = mysqli_query($con,$sql);
if (mysqli_num_rows($result) > 0) {
    echo "<script type='text/javascript'>alert('UserName already Exists')</script>";
	echo '<script>window.location.href = "signup.html";</script>';
    $valid = 0;
}
$sql1 = "select * from users where email = '$email'";
$result1 = mysqli_query($con, $sql1);
if (mysqli_num_rows($result1) > 0) {
    echo "<script type='text/javascript'>alert('Email Already Exists')</script>";
	echo '<script>window.location.href = "signup.html";</script>';
    $valid = 0;
}

if ($valid == 1) {
    $stmt = $con -> prepare("INSERT INTO users(username, course, college, department, email, password) VALUES(?, ?, ?, ?, ?, ?)");
    $stmt -> bind_param("ssssss", $username,$course,$college,$department,$email,$pwd);
    $stmt -> execute();
    echo '<script>window.location.href = "signin.html";</script>';
	$stmt ->close();
}


$con -> close();
?>
