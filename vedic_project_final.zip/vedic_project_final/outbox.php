<?php
session_start();
include_once "dbconfig.php";
include_once "pagination.php";
$id = $_SESSION['adminid'];
$sql = "select * from adminoutbox where id = '$id' order by date desc";
$result = mysqli_query($con,$sql);
?>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: ;
   color: green;
   text-align: center;
}
</style>
</head>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="logos/Vishnu_Universal_Learning.png" href="https://www.w3schools.com/html/" alt="logo" style="width:75px;height:75px;">
    </div>
    <ul class="nav navbar-nav navbar-right">
      <?php
       if (strpos($_SESSION['username'], 'coreteam') != false) {?>
         <li><a href="Inbox.php">Inbox</a></li>
         <li><a href="changePassword.php">Change Password</a></li>
         <li><a href="logout.php">Log out</a></li>
      <?php } else { ?>
        <li><a href="Inbox.php">Inbox</a></li>
        <li><a href="outbox.php">Outbox</a></li>
        <li><a href="changePassword.php">Change Password</a></li>
        <li><a href="logout.php">Log out</a></li>
    <?php } ?>
    </ul>
  </div>
</nav>
<div id = "body">
<table class="table">

<?php
$page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
if ($page <= 0) $page = 1;

$per_page = 10; // Set how many records do you want to display per page.

$startpoint = ($page * $per_page) - $per_page;

$statement = "`adminoutbox`"; // Change `records` according to your table name.

$results = mysqli_query($con,"SELECT * FROM {$statement} where adminid = '$id' LIMIT {$startpoint} , {$per_page}");
if (mysqli_num_rows($results) != 0) {
	echo '<thead>
 <tr>
    <th>Message</th>
    <th>Date</th>
	<th>Time</th>
  </tr>
  </thead>
  <tbody>';
    while ($row = mysqli_fetch_array($results)) {
			
			echo '<tr>';
			//echo '<td>'.$x. '</td>';
			echo '<td><a href="adminreply.php?msg='.$row[1].'">'.substr($row[2], 0, 50).'......</a></td>';
			echo '<td>' .$row[3]. '</td>';
			echo '<td>' .$row[4].'</td>';
		echo'</tr>';
		//$x++;
	}
} else {
     echo '<center><h1>No records are found.</h1></center>';
}
echo '</tbody>';
?>
</table>
<center>
<?php echo pagination($statement,$per_page,$page,$url='?'); ?>      </center>
</div>
<div id="footer">
</div>
<div class="footer">
<marquee behavior="scroll" direction="right"><h3>Developed and Maintained by BVRITH Students</h3></marquee>
</div>
</body>
</html>
