<?php
include_once "dbconfig.php";
session_start();
  $reply = $_POST["response"];
  $cid = $_SESSION['cid'];
  $user = $_SESSION["username"];

  $query1 = "select adminid from adminusers where username = '$user'";
  $result1 = mysqli_query($con, $query1);
  $row1 = $result1->fetch_assoc();
  $adminid = $row1["adminid"];
  date_default_timezone_set("Asia/Calcutta");
  $date = date('Y-m-d');
  $time = date('H:i:s');
  $stmt = $con->prepare("INSERT into adminoutbox(adminid,cid,reply,date,time) values(?, ?, ?, ?, ?)");
  $stmt ->bind_param("sssss",$adminid, $cid, $reply, $date, $time);
  $stmt->execute();
  $stmt->close();
  $con ->close();
  echo ("<script LANGUAGE='JavaScript'>
  window.alert('Message sent');
  window.location.href='Inbox.php';
  </script>");
  echo "posted";
?>
