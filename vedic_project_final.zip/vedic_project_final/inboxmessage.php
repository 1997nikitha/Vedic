<?php
session_start();
include_once "dbconfig.php";
include_once "pagination.php";
?>
<style>
.table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}
.td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: ;
   color: green;
   text-align: center;
}

</style>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="logos/Vishnu_Universal_Learning.png" href="https://www.w3schools.com/html/" alt="logo" style="width:75px;height:75px;">
    </div>
    <ul class="nav navbar-nav navbar-right">
      <?php
       if (strpos($_SESSION['username'], 'coreteam') != false) {?>
         <li><a href="Inbox.php">Inbox</a></li>
         <li><a href="changePassword.php">Change Password</a></li>
         <li><a href="logout.php">Log out</a></li>
      <?php } else { ?>
        <li><a href="Inbox.php">Inbox</a></li>
        <li><a href="adminoutbox.php">Outbox</a></li>
        <li><a href="changePassword.php">Change Password</a></li>
        <li><a href="logout.php">Log out</a></li>
    <?php } ?>
    </ul>
  </div>
</nav>
<?php
echo "<table  style='width:50%'>";
?>
<?php
    $username = $_SESSION["username"];
    //$_SESSION["cid"] = $id;
    if(isset($_GET['msg'])) {
      $id = $_GET['msg'];
      $_SESSION['cid'] = $id;
      $query = "SELECT * FROM studentoutbox WHERE cid = '$id'";
      $result = mysqli_query($con, $query);
      $row = mysqli_fetch_assoc($result);
      $message = $row["message"];
      $_SESSION['msg'] = $message;
      $time = $row["time"];
      $date = $row["date"];
      $subject = $row["title"];
      echo "<div id = 'msg'>
      <br><br>
      <center><h4><i>Message from student</h4></i><br>
      Date : ".$date." Time : ".$time."<br><br>
      <center><h4>Subject : ".$subject."<br><br>Message : ".$message."</center>
      </center><br><br><br></h4>";
      echo "<center>";
      echo '&nbsp<a href="inboxmessage.php?replyto='.$id.'" button class="btn-success btn">Reply</a></button>';
	  #echo $username;
	  if (strpos($username, "coreteam") == false) {
			 if ($username == "taskforce1" || $username == "taskforce2" || $username == "TASKFORCE1" || $username == "TASKFORCE2") {
				echo '&nbsp<a href="forwardtodirector.php?cid='.$id.'" button class="btn-success btn">Forward to Director</a></button>';
				echo '&nbsp<a href="forwardtocollege.php?cid='.$id.'" button class="btn-success btn">Forward to College</a></button>';
			 }
			 if ($username == "director" || $username == "DIRECTOR") {
				echo '&nbsp<a href="forwardtomanagement.php?cid='.$id.'" button class="btn-success btn">Forward to Management</a></button>';
				echo '&nbsp<a href="forwardtocollege.php?cid='.$id.'" button class="btn-success btn">Forward to College</a></button>';
			 }
			 if ($username == "management" || $username == "MANAGEMENT") {
				echo '&nbsp<a href="forwardtocollege.php?cid='.$id.'" button class="btn-success btn">Forward to College</a></button>';
			 }
				echo '&nbsp<a href = "Inbox.php" button class="btn-success btn">Back</a></button>';
			 echo "</center>";
		 }
	 }

    if(isset($_GET['replyto'])) {
      echo "<center><h4><i>Reply to student</i></h4></center>";
      $id = $_GET['replyto'];
      echo '<br><br><center><form method="post" action = "replytostudent.php">
        <textarea rows="10" cols="50" name="response" placeholder ="Leave Reply" required></textarea>
        <br><br>
        <input type="submit" button class="btn-success btn" value="send">
        &nbsp<a href = "Inbox.php" button class="btn-success btn">Back</a></button>
      </form></center>';
    }
	$sql = "update admininbox set status = 'seen' where cid = '$id' and sentTo = '$username' ";
	$result = mysqli_query($con,$sql);
?>
<div class="footer">
<marquee behavior="scroll" direction="right"><h3>Developed and Maintained by BVRITH Students</h3></marquee>
</div>
</html>
