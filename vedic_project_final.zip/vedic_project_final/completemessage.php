<?php session_start();?>
<html>
<head><title>message</title></head>
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
#header {
	 background-color:;
	 height:12%;

}
#footer {
 background-color:#009900;
 height:5%;
}
#main {
	 background-color:#ffffff;
	 height:80%;
	 padding: 10px;

}
#right {
	float: right;
	height: 12%;
	padding: 10px;

}

#divleft{
	height:100%;
	width:45%;
	float:left;
	border-radius:10px;
	margin:20px;
}
#divright{
	height:100%;
	width:45%;
	float:right;
	border-radius:10px;
	margin:20px;
}
.topnav {
  overflow: hidden;

}

.topnav a {
  float: left;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
body {
    background-image: url("images/img.jpeg");
    background-size: 100%;
    background-repeat: no-repeat;
}
</style>
<body>
<div class="topnav">
	<img src="logos/Vishnu_Universal_Learning.png"  alt="logo" style="width:70px;height:70px;">
	<div id ="right">
		<a href="studentPost.php">Post</a>
		<a href="studentInbox.php"><center>Inbox</center></a>
		<a href="studentoutbox.php">Outbox</a>
		<a href="studentprofile.php">Profile</a>
		<a href="logout.php">Logout</a>
	</div>
</div>
<br><br>
<div class="container" id = "main">
<div class="col-xs-1 col-sm-1 col-md-10 col-lg-10 col-xs-offset-0 col-sm-offset-0 col-md-offset-1 col-lg-offset-1 toppad" >
<div class="panel panel-info">
<div class="panel-body">
<div class="row">
<div class=" col-md-9 col-lg-9 ">
<table class="table table-user-information">
<h3>Message</h3>
<hr>
<?php
include_once "dbconfig.php";

if(isset($_GET['msg'])) {
      $cid = $_GET['msg'];
      $query = "SELECT * FROM studentoutbox WHERE cid = '$cid'";
      $result = mysqli_query($con, $query);
	  if(mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_row($result);
		echo '<h5>'.$row[3].'</h5>';
	  }
}
?>
</div>
</div>
</div>
</div>
</div>
</div>
<center> <a href = "studentoutbox.php" button class="btn-success btn">Back</a></button></center>
</body>
</html>
