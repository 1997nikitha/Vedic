<?php
session_start();
include_once "dbconfig.php";
$user = $_POST["username"];
$pwd = $_POST["psw"];
$pwd = MD5($pwd);

$sql = "SELECT * FROM users where username = '$user' and password = '$pwd'";
$result = mysqli_query($con,$sql);

if(mysqli_num_rows($result) > 0) {
	$row = mysqli_fetch_assoc($result);
	$_SESSION['sid'] = $row['id'];
	$_SESSION['college'] = $row['college'];
	//echo $_SESSION['college'];
	echo '<script>window.location.href = "studentPost.php";</script>';
} else {
		echo "<script type='text/javascript'>alert('Invalid Credentials!')</script>";
		echo '<script>window.location.href = "signin.html";</script>';
}

?>
