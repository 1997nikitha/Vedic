<?php session_start();
include_once "dbconfig.php";
if(isset($_GET['cid'])) {
  $cid = $_GET['cid'];
  //echo $cid;
  $query = "SELECT * FROM studentoutbox WHERE cid = '$cid'";
  $result = mysqli_query($con, $query);
  $row = mysqli_fetch_assoc($result);
  $student_id = $row["id"];
  //echo $student_id;
  $query1 = "SELECT * FROM users WHERE id = '$student_id'";
  $result1 = mysqli_query($con, $query1);
  $row1 = mysqli_fetch_assoc($result1);
  $college = $row1["college"];
  $status = "unseen";
  //echo $college;
  $stmt = $con->prepare("INSERT INTO admininbox VALUES (?,?,?)");
  $stmt->bind_param("sss", $cid, $college, $college);
  //echo $student_id . $college;
  $stmt->execute();
  $stmt->close();
  $con->close();
  echo ("<script LANGUAGE='JavaScript'>
  window.alert('Successfully Forwarded to college!!');
  window.location.href='Inbox.php';
  </script>");

}
?>
