<?php

$servername = "localhost";
$name = "srividya";
$password = "srividyaswamy";
$dbname = "vedicproject";

$con=mysqli_connect($servername,$name,$password,$dbname);
if(!$con)
	echo "not connected";
?>
