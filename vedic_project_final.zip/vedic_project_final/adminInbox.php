<?php
session_start();
include_once "dbconfig.php";
include_once "pagination.php";
?>
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<style>
#body {
  marigin:0;
  height:100%;
}


#table {
  marigin:5% auto 0 auto;
  width:800px;
  height:auto;
  overflow:hidden;
  background:#f1f1f1;
}
#table tr {
  width:100%;
}
#table tr, th {
  background: #3e3e3e;
  padding: 5px;
  text-align: center;
  color:#fff !important;
}
#table tr, th, table tr td {
  padding:10px;
  color:#999;
  font-family:arial;
  font-size:12px;
  text-align:center;
  border-left:1px solid #fff;
  border-right:1px solid #fff;
}
#table tr, td{
  border-bottom: 2px solid #fff;
}
#header {
 height:5%;

}
#footer {
 background-color:#009900;
 height:5%;
}
#body {
 background-color:#ffffff;
 height:80%;
 padding: 10px;

}
#divleft{
height:100%;
width:45%;
float:left;
border-radius:10px;
margin:20px;
}
#divright{

height:100%;

width:45%;

float:right;

border-radius:10px;

margin:20px;

}

</style>
<body>
<div class = "topnav">
  <a href="http://bvrithyderabad.edu.in/html/">
	<img src="logos/Vishnu_Universal_Learning.png" href="https://www.w3schools.com/html/" alt="logo" style="width:50px;height:50px;">
      <?php
       if (strpos($_SESSION['username'], 'coreteam') != false) {?>
         <div id = "right">";
              <a href = "admin/Inbox.php" button class="btn-success btn">Inbox</a></button>
              <a href = "admin/changePassword.php" button class="btn-success btn">Change Password</a></button>
              <a href = "logout.php" button class="btn-success btn">Logout</a></button>
         </div>
      <?php } else { ?>
          <div id = "right">
              <a href = "Inbox.php" button class="btn-success btn">Inbox</a></button>
              <a href = "outbox.php" button class="btn-success btn">Outbox</a></button>
              <a href = "changePassword.php" button class="btn-success btn">Change Password</a></button>
              <a href = "logout.php" button class="btn-success btn">Logout</a></button>
          </div>
      <?php } ?>
</div>

<?php
		$user = $_SESSION["username"];
		$page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
		if ($page <= 0) $page = 1;
		$per_page = 10; // Set how many records do you want to display per page.
		$startpoint = ($page * $per_page) - $per_page;
		$statement = "admininbox where sentTo = '$user' order by cid"; // Change `records` according to your table name
		$results = mysqli_query($con,"SELECT * FROM {$statement} desc LIMIT {$startpoint} , {$per_page}");
		echo '<br>';
        echo "<center><table  style='width:50%'>";

        if (mysqli_num_rows($results) != 0) {
            echo "<tr><th>Message</th><th>Subject</th><th>Date</th><th>Time</th>";
            while($row = mysqli_fetch_array($results)) {
              $id = $row["cid"];
              $sql1 = "select * from studentoutbox where cid = '$id'";
              $result1 = mysqli_query($con, $sql1);
              $row1 = $result1->fetch_assoc();
              $student_id = $row1["id"];
              $subject = $row1["title"];
              $sql2 = "select * from users where id = '$student_id'";
              $result2 = mysqli_query($con, $sql2);
              $row2 = $result2->fetch_assoc();
              $college = $row2["college"];
              $_SESSION["college"] = $college;
              $time = $row1["time"];
              $date = $row1["date"];
              $complaint = $row1["message"];
              $_SESSION["status"] = $row["status"];
			  if($_SESSION['status'] == 'unseen')
				  echo '<tr><td><strong><a href="admin/inboxmessage.php?msg='.$id.'" style = "color:black;font-size:16px">'."Message from ". $college ." student ". $time .'</a></strong></td></tr>';
			  else
				echo '<tr><td><a href="admin/inboxmessage.php?msg='.$id.'" style = "color:black;font-size:16px" >'."Message from ". $college ." student ". $time .'</a></strong></td></tr>';
            }
        } else {
            echo "Empty Inbox";
        }
        echo "</center>";
		echo '</table>';
?>
<center><?php echo pagination($statement,$per_page,$page,$url='?'); ?> </center>
</body>
</html>
