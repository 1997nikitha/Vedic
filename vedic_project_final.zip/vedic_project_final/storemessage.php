<?php
session_start();
include_once "dbconfig.php";
$_SESSION['sid'] = $_SESSION['id'];
$msg = $_POST["view"];
$title = $_POST["title"];
date_default_timezone_set("Asia/Calcutta");
$date = date('Y-m-d');
$time = date('H:i:s');
$stmt = $con-> prepare("INSERT INTO studentoutbox(id,title,message,date,time) VALUES (?,?,?,?,?)");
$stmt-> bind_param("sssss",$_SESSION['sid'],$title,$msg,$date,$time);
$stmt-> execute();
$query = "select * from studentoutbox order by cid desc";
$result1 = mysqli_query($con, $query);
$row1 = mysqli_fetch_row($result1);
$msgno = $row1[1];
$to = "taskforce1";
$status = "unseen";
$stmt = $con->prepare("INSERT INTO admininbox VALUES (?,?,?)");
$stmt->bind_param("sss",$msgno,$to,$status);
$stmt->execute();
$stmt->close();
$to = "taskforce2";
$stmt = $con->prepare("INSERT INTO admininbox VALUES (?,?,?)");
$stmt->bind_param("sss",$msgno,$to,$status);
$stmt->execute();
$stmt->close();
$college = $_SESSION['college'];
$receiver1 =  $college . "coreteam1";
$stmt = $con->prepare("INSERT INTO admininbox VALUES (?,?,?)");
$stmt->bind_param("sss",$msgno,$receiver1,$status);
$stmt->execute();
$stmt->close();
$receiver2 = $college . "coreteam2";
$stmt = $con->prepare("INSERT INTO admininbox VALUES (?,?,?)");
$stmt->bind_param("sss",$msgno,$receiver2,$status);
$stmt->execute();
$stmt->close();
$con->close();
echo ("<script LANGUAGE='JavaScript'>
window.alert('Message Posted');
window.location.href='studentPost.php';
</script>");
$id = $_SESSION["college"];
echo $id;

?>
