<?php session_start(); ?>
<html>
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<style>
#header{
	height:5%;
}
#divr{
	float:right;
}
body {
    marigin:0;
    height:100%;
    background-color:#ffffff;
    height:80%;
    padding: 10px;
    background-size: 100%;
    background-repeat: no-repeat;

}
.login {
	position: absolute;
	top: 50%;
	left: 50%;
	margin: -150px 0 0 -150px;
	width:300px;
	height:300px;
}
.login h1 { color: #fff; text-shadow: 0 0 10px rgba(0,0,0,0.3); letter-spacing:1px; text-align:center; }

input[type=text], input[type=password] {
    width: 80%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}


.button {
    background-color: #006600;
    border: none;
    color: white;
    padding: 8px 8px;
    text-align: center;
    font-size: 16px;
    border-radius:6px;
	 cursor: pointer;
    width: 100%;
}
button:hover {
    opacity: 0.8;
}
.button1 {
    background-color: #006600; /* Green */
    border: none;
    border-radius: 5px;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 18px;
    margin: 4px 2px;
    cursor: pointer;
    width: 25%;
}

.container {
    padding: 16px;
}

.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: ;
   color: green;
   text-align: center;
}

</style>

</div>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="logos/Vishnu_Universal_Learning.png" href="https://www.w3schools.com/html/" alt="logo" style="width:75px;height:75px;">
    </div>
    <ul class="nav navbar-nav navbar-right">
      <?php
       if (strpos($_SESSION['username'], 'coreteam') != false) {?>
         <li><a href="Inbox.php">Inbox</a></li>
         <li><a href="changePassword.php">Change Password</a></li>
         <li><a href="logout.php">Log out</a></li>
      <?php } else { ?>
        <li><a href="Inbox.php">Inbox</a></li>
        <li><a href="outbox.php">Outbox</a></li>
        <li><a href="changePassword.php">Change Password</a></li>
        <li><a href="logout.php">Log out</a></li>
    <?php } ?>
    </ul>
  </div>
</nav>
<center>
<form  method="POST" action="password.php">
  <h2>Change Password</h2>


	<div class="container">
	<table align="center" width="50%">
	<tr>
	<td><label><b>New Password</b></label></td>
    <td><input type="password" placeholder="New Password" name="newPassword"></td>
	</tr>
	<tr>
	<td><b>Confirm New Password<b></label></td>
    <td><input type="password"  placeholder="Confirm Password" name="confirmPassword"></td>
	</tr>
	</table>
	<center>
   <button class="button1" >Change Password</button>
    </center>

  </div>

    </form>
	</center>
	
	<div class="footer">
<marquee behavior="scroll" direction="right"><h3>Developed and Maintained by BVRITH Students</h3></marquee>
</div>
	</body>
</html>
