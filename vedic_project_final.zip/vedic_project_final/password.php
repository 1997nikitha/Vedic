<?php

session_start();
include_once "dbconfig.php";

/*if (!(isset($_SESSION['username']) || $_SESSION['username'] == ''))
{
    header("location:login.php");
}*/



$password1 = mysqli_real_escape_string($con, $_POST['newPassword']);
$password2 = mysqli_real_escape_string($con, $_POST['confirmPassword']);
$username = mysqli_real_escape_string($con, $_SESSION['username']);

if ($password1 <> $password2)
{
    
	echo "<script type='text/javascript'>alert('your passwords do not match!')</script>";
}
else if (mysqli_query($con, "UPDATE adminusers SET password=MD5('$password1') WHERE username='$username'"))
{
    
	echo "<script type='text/javascript'>alert('You have successfully changed your password!')</script>";
		echo '<script>window.location.href = "Inbox.php";</script>';
}
else
{
    mysqli_error($con);
}


mysqli_close($con);

?>