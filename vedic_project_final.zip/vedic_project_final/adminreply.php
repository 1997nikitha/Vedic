<?php session_start();
include_once "dbconfig.php";
?>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="logos/Vishnu_Universal_Learning.png" href="https://www.w3schools.com/html/" alt="logo" style="width:75px;height:75px;">
    </div>
    <ul class="nav navbar-nav navbar-right">
      <?php
       if (strpos($_SESSION['username'], 'coreteam') != false) {?>
         <li><a href="Inbox.php">Inbox</a></li>
         <li><a href="changePassword.php">Change Password</a></li>
         <li><a href="logout.php">Log out</a></li>
      <?php } else { ?>
        <li><a href="Inbox.php">Inbox</a></li>
        <li><a href="outbox.php">Outbox</a></li>
        <li><a href="changePassword.php">Change Password</a></li>
        <li><a href="logout.php">Log out</a></li>
    <?php } ?>
    </ul>
  </div>
</nav>
</head>
<body>
<br><br>
<div class="container" id = "main">
<div class="col-xs-1 col-sm-1 col-md-10 col-lg-10 col-xs-offset-0 col-sm-offset-0 col-md-offset-1 col-lg-offset-1 toppad" >
<div class="panel panel-info">
<div class="panel-body">
<div class="row">
<div class=" col-md-9 col-lg-9 ">
<table class="table table-user-information">
<hr>
<?php
   if(isset($_GET['msg'])) {
      echo "<h3>Message from student</h3>";
      $cid = $_GET['msg'];
      $query = "SELECT * FROM studentoutbox WHERE cid = '$cid'";
      $result = mysqli_query($con, $query);
            if(mysqli_num_rows($result) > 0) {
                      $row = mysqli_fetch_row($result);
                      echo '<h4>'.$row[3].'</h4><br>';
            }
      $query1 = "SELECT * FROM adminoutbox WHERE cid = '$cid'";
	  //echo $cid;
      $result1 = mysqli_query($con, $query1);
      if(mysqli_num_rows($result1) > 0) {
		
		while ($row1 = mysqli_fetch_array($result1)) {
			echo "<h4>Reply on ".$row1["date"]." ".$row1["time"].":</h4>";
            echo '<h4>'.$row1[2].' </h4><br>';
		}
       }
   }
?>
</div>
</div>
</div>
</div>
</div>
</div>
<center> <a href = "outbox.php" button class="btn-success btn">Back</a></button></center>
</body>