<?php
session_start();
include_once "dbconfig.php";
$_SESSION['id'] = $_SESSION['sid'];
 
$college = $_SESSION['college'];

?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<title>Post</title>
<style>

#header {
 background-color:;
 height:5%;
}
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: ;
   color:green;
   text-align: center;
}
body {
	background-image: url("images/vedic4.jpg");
    background-size: 100%;
    background-repeat: no-repeat;
}


#body {

 background-color: white ;
 height:80%;
 padding: 10px;

}


#divleft{

float: left;

height: 100%;

width: 55%;

padding: 5px;
}

#right {
	float: right;
	height: 12%;
	padding: 10px;

}
#divright {

float: right;

height: 100%;

width: 45%;

padding: 5px;

}

.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #006600;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 10px;
  width: 28%;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}
.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}
.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}
.button:hover span {
  padding-right: 25px;
}
.button:hover span:after {
  opacity: 1;
  right: 0;
}
.image {
    opacity: ;
    filter: alpha(opacity=50); /* For IE8 and earlier */
}
.image:hover {
    opacity: 1.0;
    filter: alpha(opacity=100); /* For IE8 and earlier */
}
.topnav {
  overflow: hidden;
  background-color: ;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<script>
$(document).ready(function() {
  $("#word_count").on('keyup', function() {
    var words = this.value.match(/\S+/g).length;

    if (words > 750) {
      // Split the string on first 200 words and rejoin on spaces
      var trimmed = $(this).val().split(/\s+/, 750).join(" ");
      // Add a space at the end to make sure more typing creates new words
      $(this).val(trimmed + " ");
    }
    else {
      $('#display_count').text(words);
      $('#word_left').text(750-words);
    }
  });
});
</script>
<body>
<div class="topnav">

	<img src="logos/Vishnu_Universal_Learning.png"alt="logo" style="width:50px;height:50px;">
	<div id ="right">
		<a href="studentPost.php">Post</a>
		<a href="studentInbox.php"><center>Inbox</center></a>
		<a href="studentoutbox.php">Outbox</a>
		<a href="studentprofile.php">Profile</a>
		<a href="logout.php">Logout</a>
	</div>
</div>
<form action="storemessage.php" method="post">
<div id = "body">
<div id = "divleft">
<br>
<textarea style="background:transparent;" rows="1" cols="80" maxlength="100" name="title" placeholder="Add title...." required></textarea>
<textarea style="background:transparent;" rows="18" cols="80" id ="word_count" name="view" placeholder="Share your views here..." required></textarea><br>
<strong>***Maximum 750 words
Total word Count : <span id="display_count">0</span> words. <br></strong>
<button class="button" style="vertical-align:middle;" name ="post"><span>Post </span></button>
</div>
<div id = "divright"><br>
<?php
if($college == "BVRICE"){
	echo '<img class="image" src="images/bvrice.jpeg" style="width:100%;height:80%;transform:;float:left; " />'; 
} else if($college == "BVRITN"){
	echo '<img class="image" src="images/bvritn.jpg" style="width:100%;height:80%;transform:;float:left; " />'; 
}else if($college == "BVRITH"){
	echo '<img class="image" src="images/bvrith.jpg" style="width:100%;height:80%;transform:;float:left;" />'; 
} else if($college == "SVCP"){
	echo '<img class="image" src="images/svcp.jpg" style="width:100%;height:80%;transform:;float:left;" />'; 
} else if($college == "SVECW"){
	echo '<img class="image" src="images/svecw.jpg" style="width:100%;height:80%;transform:;float:left;" />'; 
} else if($college == "VIPER"){
	echo '<img class="image" src="images/viper.jpg" style="width:100%;height:80%;transform:;float:left;" />'; 
} else if($college == "VIT"){
	echo '<img class="image" src="images/vit.jpg" style="width:100%;height:80%;transform:;float:left;" />'; 
} else if($college = "VDC") {
	echo '<img class="image" src="images/vdc.jpg" style="width:100%;height:80%;transform:;float:left;" />'; 
}
?>
</div>
</div>
</form>
<div class="footer"><font color="white">
<marquee behavior="scroll" direction="right"><h3>Developed and Maintained by BVRITH Students</h3></marquee>
</div>
</body>
</html>
