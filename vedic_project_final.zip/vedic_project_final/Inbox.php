<?php
session_start();
include_once "dbconfig.php";
include_once "pagination.php";
?>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>

.table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}
.td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: ;
   color: green;
   text-align: center;
}

</style>
</head>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="logos/Vishnu_Universal_Learning.png" href="https://www.w3schools.com/html/" alt="logo" style="width:75px;height:75px;">
    </div>
    <ul class="nav navbar-nav navbar-right">
      <?php
       if (strpos($_SESSION['username'], 'coreteam') != false) {?>
         <li><a href="Inbox.php">Inbox</a></li>
         <li><a href="changePassword.php">Change Password</a></li>
         <li><a href="logout.php">Log out</a></li>
      <?php } else { ?>
        <li><a href="Inbox.php">Inbox</a></li>
        <li><a href="outbox.php">Outbox</a></li>
        <li><a href="changePassword.php">Change Password</a></li>
        <li><a href="logout.php">Log out</a></li>
    <?php } ?>
    </ul>
  </div>
</nav>
<body>
<?php
  $user = $_SESSION["username"];
  $page = (int)(!isset($_GET["page"]) ? 1 : $_GET["page"]);
  if ($page <= 0) $page = 1;
  $per_page = 10; // Set how many records do you want to display per page.
  $startpoint = ($page * $per_page) - $per_page;
  $statement = "admininbox where sentTo = '$user' order by cid desc"; // Change `records` according to your table name
  $results = mysqli_query($con,"SELECT * FROM {$statement} LIMIT {$startpoint} , {$per_page}");
  echo '<br>';
      echo "<center><table  style='width:100%'>";

      if (mysqli_num_rows($results) != 0) {
          echo "<tr><th>Message</th><th>Subject</th><th>Date</th><th>Time</th>";
          while($row = mysqli_fetch_array($results)) {
            $id = $row["cid"];
            $sql1 = "select * from studentoutbox where cid = '$id'";
            $result1 = mysqli_query($con, $sql1);
            $row1 = $result1->fetch_assoc();
            $student_id = $row1["id"];
            $subject = $row1["title"];
            $sql2 = "select * from users where id = '$student_id'";
            $result2 = mysqli_query($con, $sql2);
            $row2 = $result2->fetch_assoc();
            $college = $row2["college"];
            $_SESSION["college"] = $college;
            $time = $row1["time"];
            $date = $row1["date"];
            $complaint = $row1["message"];
            $_SESSION["status"] = $row["status"];
            if($_SESSION['status'] == 'unseen')
              echo '<tr><td><strong><a href="inboxmessage.php?msg='.$id.'" style = "color:black;font-size:16px">'."Message from ". $college ." student </a></strong></td><td>$subject</td><td>$date</td><td>$time</td></tr>";
            else
              echo '<tr><td><a href="inboxmessage.php?msg='.$id.'" style = "color:black;font-size:16px">'."Message from ". $college ." student </a></td><td>$subject</td><td>$date</td><td>$time</td></tr>";
        }
      } else {
          echo "Empty Inbox";
      }
      echo "</center>";
  echo '</table>';
?>
<center><?php echo pagination($statement,$per_page,$page,$url='?'); ?> </center>

<div class="footer">
<marquee behavior="scroll" direction="right"><h3>Developed and Maintained by BVRITH Students</h3></marquee>
</div>
</body>
